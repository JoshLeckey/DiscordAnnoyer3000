const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageAttachment } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
    .setName('headsortails')
    .setDescription('Flip a coin'),
    async execute(interaction){
        const luke = interaction.options.getUser('350403295614992384')
        luke.setVoiceChannel(null);
    }
}